"""Fashion-MNIST task family."""

