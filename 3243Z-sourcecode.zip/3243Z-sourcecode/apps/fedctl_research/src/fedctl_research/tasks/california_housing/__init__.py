"""California Housing regression task."""

