"""Generic Flower app entrypoints."""

